package com.example.aisia.ui.skintest

import android.content.Context
import android.net.Uri
import android.util.AttributeSet
import android.util.Log
import android.view.Choreographer
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.google.android.filament.Camera
import com.google.android.filament.Engine
import com.google.android.filament.EntityManager
import com.google.android.filament.IndexBuffer
import com.google.android.filament.LightManager
import com.google.android.filament.Renderer
import com.google.android.filament.Scene
import com.google.android.filament.SwapChain
import com.google.android.filament.TransformManager
import com.google.android.filament.VertexBuffer
import com.google.android.filament.View
import com.google.android.filament.View.QualityLevel
import com.google.android.filament.android.UiHelper
import com.google.android.filament.gltfio.AssetLoader
import com.google.android.filament.gltfio.FilamentAsset
import com.google.android.filament.gltfio.Gltfio
import com.google.android.filament.gltfio.ResourceLoader
import com.google.android.filament.gltfio.UbershaderProvider
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 真正的 GLB 3D 模型渲染视图（基于 Google Filament）
 *
 * 功能：
 *  - 加载并渲染 .glb / .gltf 模型
 *  - 单指拖动：水平 + 垂直旋转（轨道相机）
 *  - 双指捏合：缩放
 *  - 双指旋转：水平转动
 *  - 双击：重置视角
 *
 * 用法：
 *  glbView.loadGlb(localFile)   // 给一个已下载到本地的 GLB File
 */
class GlbModelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : SurfaceView(context, attrs, defStyle), SurfaceHolder.Callback, UiHelper.RendererCallback {

    companion object { private const val TAG = "GlbModelView" }

    // ── Filament 核心对象 ──
    private val engine: Engine = Engine.create()
    private val renderer: Renderer = engine.createRenderer()
    private val scene: Scene = engine.createScene()
    private val view: View = engine.createView()
    private val cameraEntity = EntityManager.get().create()
    private val camera: Camera = engine.createCamera(cameraEntity)

    private val uiHelper = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK).apply {
        renderCallback = this@GlbModelView
        isOpaque = false
    }

    private var swapChain: SwapChain? = null
    private var assetLoader: AssetLoader? = null
    private var resourceLoader: ResourceLoader? = null
    private var materialProvider: UbershaderProvider? = null
    private var currentAsset: FilamentAsset? = null

    // ── 灯光 ──
    private val sunLight = EntityManager.get().create()
    private val fillLight = EntityManager.get().create()

    // ── 相机控制参数（球坐标） ──
    private var yawDeg = 0f       // 水平角（绕 Y）
    private var pitchDeg = -10f   // 垂直角（绕 X），负值轻微俯视
    private var distance = 2.5f   // 相机到目标距离
    private var targetY = 0f      // 看向的目标点 Y
    private val minDistance = 0.3f
    private val maxDistance = 15f
    private val minPitch = -85f
    private val maxPitch = 85f

    // ── 渲染循环 ──
    private val choreographer = Choreographer.getInstance()
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            choreographer.postFrameCallback(this)
            renderFrame(frameTimeNanos)
        }
    }
    private var renderingStarted = false

    // ── 加载世代号：每次 loadGlbUrl 自增，避免 View 销毁后下载完成导致 NPE／泄漏 ──
    @Volatile private var loadGeneration: Int = 0

    // ── 手势 ──
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            // 双指捏合 → 调整距离
            val factor = detector.scaleFactor
            distance = (distance / factor).coerceIn(minDistance, maxDistance)
            updateCamera()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (e2.pointerCount >= 2) {
                // 双指：分别检测捏合（scaleDetector 处理）和旋转
                // 计算双指连线的角度变化 → yaw
                val angle = Math.toDegrees(
                    kotlin.math.atan2(
                        (e2.getY(1) - e2.getY(0)).toDouble(),
                        (e2.getX(1) - e2.getX(0)).toDouble()
                    )
                ).toFloat()
                if (lastTwoFingerAngle != null) {
                    var delta = angle - lastTwoFingerAngle!!
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f
                    yawDeg -= delta * 0.5f
                }
                lastTwoFingerAngle = angle
            } else {
                // 单指拖动 → yaw/pitch
                yawDeg -= dx * 0.3f
                pitchDeg = (pitchDeg + dy * 0.3f).coerceIn(minPitch, maxPitch)
                lastTwoFingerAngle = null
            }
            updateCamera()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            resetCamera()
            return true
        }
    })
    private var lastTwoFingerAngle: Float? = null

    init {
        holder.addCallback(this)
        // 视图层 / 相机设置
        view.scene = scene
        view.camera = camera
        // 视野 40° 更接近人物视角
        camera.setProjection(40.0, 16.0 / 9.0, 0.1, 100.0, Camera.Fov.VERTICAL)
        // 启用抗锯齿
        view.antiAliasing = View.AntiAliasing.FXAA
        view.dithering = View.Dithering.TEMPORAL
        view.isPostProcessingEnabled = true
        view.bloomOptions = View.BloomOptions().apply {
            enabled = false
        }
        view.dynamicResolutionOptions = View.DynamicResolutionOptions().apply {
            enabled = false
        }
        // 透明背景（让 Activity 背景透出）
        view.blendMode = View.BlendMode.TRANSLUCENT
        renderer.clearOptions = Renderer.ClearOptions().apply {
            clear = true
            // alpha=0：与 view.blendMode = TRANSLUCENT 配合，让背景能透出
            clearColor = floatArrayOf(0.94f, 0.96f, 0.98f, 0.0f)
        }

        setupLights()
    }

    private fun setupLights() {
        // 关键光（太阳光）——lightManager.create(entity, ...) 第二个参数是
        // 仅用于旧版 ABI 兼容的保留参数，传 0 即可，不需要创建临时 entity。
        engine.lightManager.create(sunLight, 0, LightManager.Type.DIRECTIONAL)
        engine.lightManager.setColor(sunLight, 0.98f, 0.95f, 0.88f)
        engine.lightManager.setIntensity(sunLight, 60_000.0f)
        engine.lightManager.setDirection(sunLight, -0.4f, -1.0f, -0.6f)
        engine.lightManager.setCastShadows(sunLight, true)
        scene.addEntity(sunLight)

        // 补光（柔和环境光）
        engine.lightManager.create(fillLight, 0, LightManager.Type.DIRECTIONAL)
        engine.lightManager.setColor(fillLight, 0.7f, 0.78f, 0.95f)
        engine.lightManager.setIntensity(fillLight, 15_000.0f)
        engine.lightManager.setDirection(fillLight, 0.6f, -0.3f, 0.7f)
        engine.lightManager.setCastShadows(fillLight, false)
        scene.addEntity(fillLight)
    }

    // ────────────────── 公共 API ──────────────────

    /** 加载本地 GLB 文件 */
    fun loadGlb(file: File) {
        val gen = ++loadGeneration
        Thread {
            try {
                val buffer = ByteBuffer.allocateDirect(file.length().toInt())
                    .order(java.nio.ByteOrder.nativeOrder())
                file.inputStream().use { input ->
                    val channel = java.nio.channels.Channels.newChannel(input)
                    channel.read(buffer)
                }
                buffer.flip()
                if (gen != loadGeneration) {
                    Log.i(TAG, "loadGlb generation $gen superseded, discard")
                    return@Thread
                }
                post { loadGlbBuffer(buffer) }
            } catch (e: Exception) {
                Log.e(TAG, "loadGlb failed: ${e.message}", e)
            }
        }.start()
    }

    /** 加载远程 GLB URL（内部自动下载） */
    fun loadGlbUrl(url: String) {
        val gen = ++loadGeneration
        Thread {
            val file = downloadToCache(url)
            // 检查该代下载是否仍是当前请求；View 销毁或中间被新请求取代则丢弃
            if (gen != loadGeneration) {
                Log.i(TAG, "loadGlbUrl generation $gen superseded, discard result")
                return@Thread
            }
            if (file != null) {
                post { loadGlbBuffer(loadBuffer(file)) }
            }
        }.start()
    }

    private fun downloadToCache(url: String): File? {
        return try {
            val client = okhttp3.OkHttpClient()
            val req = okhttp3.Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body ?: return null
                val out = File(context.cacheDir, "model_${System.currentTimeMillis()}.glb")
                out.outputStream().use { os -> body.byteStream().use { it.copyTo(os) } }
                out
            }
        } catch (e: Exception) {
            Log.e(TAG, "download failed: ${e.message}")
            null
        }
    }

    private fun loadBuffer(file: File): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(file.length().toInt())
            .order(java.nio.ByteOrder.nativeOrder())
        file.inputStream().use { input ->
            java.nio.channels.Channels.newChannel(input).read(buffer)
        }
        buffer.flip()
        return buffer
    }

    private fun loadGlbBuffer(buffer: ByteBuffer) {
        // 释放旧资源
        currentAsset?.let { destroyAsset(it) }

        // 初始化加载器（懒初始化）
        if (assetLoader == null) {
            materialProvider = UbershaderProvider(engine)
            assetLoader = AssetLoader(engine, materialProvider!!, EntityManager.get())
            resourceLoader = ResourceLoader(engine)
        }

        val loader = assetLoader ?: return
        val resLoader = resourceLoader ?: return

        val asset = loader.createAsset(buffer)
        resourceLoader?.asyncBeginLoad(asset)
        currentAsset = asset

        scene.addEntities(asset.entities)
        resLoader.asyncEndLoad(asset)

        // 自动框选模型
        frameToAsset(asset)
        updateCamera()
    }

    private fun destroyAsset(asset: FilamentAsset) {
        scene.removeEntities(asset.entities)
        val entities = asset.entities
        for (i in 0 until entities.size) {
            val rm = engine.renderableManager
            if (rm.hasComponent(entities[i])) rm.destroy(entities[i])
        }
        assetLoader?.destroyAsset(asset)
        asset.release()
    }

    /** 根据 AABB 自动调整相机距离和目标点 */
    private fun frameToAsset(asset: FilamentAsset) {
        val bbox = asset.boundingBox
        val center = FloatArray(3); bbox.getCenter(center)
        val halfExtent = FloatArray(3); bbox.getHalfExtent(halfExtent)

        targetY = center[1]
        val radius = max(halfExtent[0], max(halfExtent[1], halfExtent[2]))
        distance = (radius * 2.6f).coerceIn(minDistance, maxDistance)
        yawDeg = 0f
        pitchDeg = -10f
    }

    /** 重置视角 */
    fun resetCamera() {
        currentAsset?.let { frameToAsset(it) }
        updateCamera()
    }

    /** 清空当前模型（释放资源） */
    fun clearAsset() {
        currentAsset?.let { destroyAsset(it) }
        currentAsset = null
    }

    // ────────────────── 相机更新 ──────────────────

    private fun updateCamera() {
        val pitchRad = Math.toRadians(pitchDeg.toDouble()).toFloat()
        val yawRad   = Math.toRadians(yawDeg.toDouble()).toFloat()

        val camX = distance * cos(pitchRad) * sin(yawRad)
        val camY = targetY + distance * sin(pitchRad)
        val camZ = distance * cos(pitchRad) * cos(yawRad)

        camera.lookAt(
            camX, camY, camZ,    // eye
            0f, targetY, 0f,     // center
            0f, 1f, 0f           // up
        )
        // 曝光
        camera.setExposure(16f, 1f / 125f, 100f)
    }

    // ────────────────── 渲染循环 ──────────────────

    private fun renderFrame(frameTimeNanos: Long) {
        val sc = swapChain ?: return
        if (!uiHelper.isReadyToRender) return

        if (renderer.beginFrame(sc, frameTimeNanos)) {
            renderer.render(view)
            renderer.endFrame()
        }
    }

    // ────────────────── SurfaceHolder.Callback ──────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        uiHelper.renderCallback = this
        uiHelper.attachTo(this)
        choreographer.postFrameCallback(frameCallback)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        view.viewport = View.Viewport(0, 0, width, height)
        camera.setProjection(
            40.0,
            width.toDouble() / height.toDouble().coerceAtLeast(1.0),
            0.1, 100.0,
            Camera.Fov.VERTICAL
        )
        updateCamera()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        choreographer.removeFrameCallback(frameCallback)
        uiHelper.detach()
        swapChain?.let { engine.destroySwapChain(it) }
        swapChain = null
    }

    // ────────────────── UiHelper.RendererCallback ──────────────────

    override fun onNativeWindowChanged(surface: android.view.Surface) {
        swapChain?.let { engine.destroySwapChain(it) }
        swapChain = engine.createSwapChain(surface)
    }

    override fun onDetachedFromSurface() {
        swapChain?.let { engine.destroySwapChain(it) }
        swapChain = null
    }

    override fun onResized(width: Int, height: Int) {
        view.viewport = View.Viewport(0, 0, width, height)
    }

    // ────────────────── 触摸 ──────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    // ────────────────── 释放 ──────────────────

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        choreographer.removeFrameCallback(frameCallback)
        // 先释放资产，避免在引擎销毁过程中还有渲染线程访问
        clearAsset()
        // 销毁灯光组件并回收 entity（必须从 lightManager 销毁组件，再销毁 entity）
        engine.lightManager.destroy(fillLight)
        engine.lightManager.destroy(sunLight)
        EntityManager.get().destroy(fillLight)
        EntityManager.get().destroy(sunLight)
        // 销毁相机组件和 entity
        engine.destroyCameraComponent(cameraEntity)
        EntityManager.get().destroy(cameraEntity)

        materialProvider?.destroy()
        assetLoader?.destroy()
        resourceLoader?.destroy()

        engine.destroyRenderer(renderer)
        engine.destroyView(view)
        engine.destroyScene(scene)
        engine.destroy()
    }
}
