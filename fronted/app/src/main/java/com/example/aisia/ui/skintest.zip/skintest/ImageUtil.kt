package com.example.aisia.ui.skintest

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream

/**
 * 把 CameraX 的 ImageProxy（YUV_420_888）转 Bitmap，并做旋转修正。
 *
 * @param imageProxy   CameraX 帧
 * @param mirrorH      是否需要水平翻转。前置摄像头通常预览已镜像，但 ImageAnalysis 拿到的
 *                     帧通常未经镜像——业务如果希望和用户看到的预览保持一致，就需要翻转；
 *                     但 MediaPipe FaceLandmarker 对镜像画面也能识别，且坐标 x 轴方向会反。
 *                     因此约定：这里统一 **不翻转**，让 yaw/pitch 算法按真实鼻尖位置工作。
 */
object ImageUtil {

    fun toBitmap(imageProxy: ImageProxy, mirrorH: Boolean = false): Bitmap? {
        return try {
            val yBuffer = imageProxy.planes[0].buffer
            val uBuffer = imageProxy.planes[1].buffer
            val vBuffer = imageProxy.planes[2].buffer

            val ySize = yBuffer.remaining()
            val uSize = uBuffer.remaining()
            val vSize = vBuffer.remaining()

            val nv21 = ByteArray(ySize + uSize + vSize)
            yBuffer.get(nv21, 0, ySize)
            vBuffer.get(nv21, ySize, vSize)
            uBuffer.get(nv21, ySize + vSize, uSize)

            val yuvImage = YuvImage(
                nv21,
                android.graphics.ImageFormat.NV21,
                imageProxy.width,
                imageProxy.height,
                null
            )
            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, imageProxy.width, imageProxy.height), 90, out)
            val jpeg = out.toByteArray()
            var bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return null

            // 根据 rotation 旋转（前置摄像头典型 270°）
            val rotation = imageProxy.imageInfo.rotationDegrees
            if (rotation != 0 || mirrorH) {
                val matrix = Matrix().apply {
                    if (rotation != 0) postRotate(rotation.toFloat())
                    if (mirrorH) postScale(-1f, 1f)
                }
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            }

            bitmap
        } catch (e: Exception) {
            null
        }
    }
}
